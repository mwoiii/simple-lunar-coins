## 1.1.1

-Compatibility improvements

-Formatting improvements

## 1.1.0

-Updated description and README

-Reduced default coin drop chance to 4%

-Implemented enabling/disabling distributed coins

-Implemented enabling/disabling coin droplets

-Implemented enabling/disabling coin count reset at the start of a run

## 1.0.1

-Grammatical and formatting fixes

## 1.0.0

First release:

-Coin drop chance now fixed at 5%

-Coin drop chance no longer decreases (multiplier set to 1) upon a successful drop

-Players start with 5 coins

-All of the above numbers are configurable

-Lunar coins no longer drop as an interactable, but instead drop in a similar fashion to gold, and are instantly collected
