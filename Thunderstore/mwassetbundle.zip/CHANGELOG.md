## 1.2.6
- README changes

## 1.2.5
- You know the drill

## 1.2.4
- Regularly-scheduled fix after any game update of any variety

## 1.2.3
- Updated dependency string
- Modified default settings to only replace droplet effect and distribute coins among all players
  - Before, changed settings were 2% initial coin chance, coin chance multiplier 1x, and reset coins each run: true

## 1.2.2
- Literally the same thing as before

## 1.2.1
- Fixed incorrect line reference after new patch

## 1.2.0

- Added support for the Seekers of the Storm update
  - Support for ProperSave and Risk of Options remains implemented, hopefully
  - Coin sound effect unintentionally now only plays on occasion and I have no idea what I'm meant to do about this

## 1.1.6

- Stopped the mod breaking without ProperSave (I hope). I keep releasing this mod entirely broken. It's a little embarrassing

## 1.1.5

- Added support for ProperSave

## 1.1.4

- Coin multiplier now works when editied with Risk of Options without restart

## 1.1.3

- Fixed mod not working teehee I uploaded the wrong version

## 1.1.2

- Reduced default coin drop chance to 2%

- Added support for Risk of Options

## 1.1.1

- Compatibility improvements

- Formatting improvements

## 1.1.0

- Updated description and README

- Reduced default coin drop chance to 4%

- Implemented enabling/disabling distributed coins

- Implemented enabling/disabling coin droplets

- Implemented enabling/disabling coin count reset at the start of a run

## 1.0.1

- Grammatical and formatting fixes

## 1.0.0

First release:

- Coin drop chance now fixed at 5%

- Coin drop chance no longer decreases (multiplier set to 1) upon a successful drop

- Players start with 5 coins

- All of the above numbers are configurable

- Lunar coins no longer drop as an interactable, but instead drop in a similar fashion to gold, and are instantly collected
